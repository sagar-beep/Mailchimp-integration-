Run the following command in root directory of an app in command prompt.

Install node packages

npm install

Run the following command in root directory of an app in command prompt.

node index.js